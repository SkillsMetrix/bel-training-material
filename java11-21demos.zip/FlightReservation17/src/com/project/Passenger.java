package com.project;

public record Passenger(String name,String email) {
	
	@Override
	public String toString() {
		return name() + "< " + email() + " >";
	}
	}
	
