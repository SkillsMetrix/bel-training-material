package com.pro;

import java.util.ArrayList;
import java.util.Optional;

import com.project.Employee;

public class EmployeeCrudLambdaStream {

	public static void main(String[] args) {
		ArrayList<Employee> al = new ArrayList<Employee>();
		al.add(new Employee(101, "John", 50000));
		al.add(new Employee(102, "Sam", 60000));
		al.add(new Employee(103, "Rita", 55000));

		// Read all the Records
		al.stream().forEach(e -> System.out.println(e));
		
		// read employee with id=102
		
				  
		 Optional<Employee> searchemp= al.stream()
				.filter(e -> e.getEmpId()== 102)
				 .findFirst();
		 if(searchemp.isPresent()) {
			 System.out.println(searchemp);	
		 }else {
			 System.out.println("employee not found");
		 }
		 
		

		// update employee salary with id=101
		System.out.println(" To update specific record ");
		for (Employee em : al) {
			if (em.getEmpId() == 101) {
				em.setIncome(55000);
				System.out.println(em);
				break;
			}
		}
		// delete employee
		System.out.println(" To delete specific record ");
		 
		 al.removeIf(e ->e.getEmpId()== 103);
	}

}
