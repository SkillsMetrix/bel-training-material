package com.project;

public class Employee {
	 
	
	private int empId;
	private String empName;
	private int income;
	public Employee(int empId, String empName, int income) {
	 
		this.empId = empId;
		this.empName = empName;
		this.income = income;
	}
	
	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}
	

	public int getIncome() {
		return income;
	}

	public void setIncome(int income) {
		this.income = income;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", income=" + income + "]";
	}

	 
	
	
	

}
