package java11demos;

public class HttpExamples {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
