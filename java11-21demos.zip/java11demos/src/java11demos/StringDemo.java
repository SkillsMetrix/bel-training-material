package java11demos;

public class StringDemo {
	public static void main(String[] args) {
		// isBlank example
		String s1=" hello ";
		String s2="  ";
		String s3= " \t ";
		String s4= "hello";
		
//		System.out.println(s1.isBlank());
//		System.out.println(s2.isBlank());
//		System.out.println(s3.isBlank());
//		System.out.println(s4.isBlank());
		
		//lines() example
		String linesData= "A\nB\nC\nD";
		//linesData.lines().forEach(System.out::println);
		
		// whitespace stripping methods strip ,stripleading, striptrailing
		String demo2= """
				Welcome,
				to
				FS
				""";
		//System.out.println(s1);
		//System.out.println(s1.strip());
		//System.out.println(demo2.stripIndent());
		
		// repeat
		System.out.println("Welcome".repeat(3));
	}

}
