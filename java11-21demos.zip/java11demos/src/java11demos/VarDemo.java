package java11demos;

import java.util.List;

public class VarDemo {
	public static void main(String[] args) {
		var uname="Admin";
		var age=30;
		var price=99.50;
		var active= true;
		
		// using collections
		var userNames= List.of("Admin","Manager","QA");
		
		for (var item: userNames) {
			System.out.println(item);
		}
		
		System.out.println(uname.getClass().getSimpleName());
		System.out.println(uname);
	}

}
