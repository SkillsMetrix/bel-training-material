module java11demos {
	requires java.net.http;
}