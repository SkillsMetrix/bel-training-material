package java11exam;
import java.io.IOException;
import java.net.*;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
public class HttpExamples {

	public static void main(String[] args) throws Exception {
		 var client= HttpClient.newHttpClient();
		 
		 var request= HttpRequest.newBuilder()
				 .uri(URI.create("https://jsonplaceholder.typicode.com/users"))
		 			.GET().build();
		 
		 var response= client.send(request, HttpResponse.BodyHandlers.ofString());
		 System.out.println("Status Code: "+ response.statusCode());
		 System.out.println("Body: "+ response.body());
				 

	}

}
