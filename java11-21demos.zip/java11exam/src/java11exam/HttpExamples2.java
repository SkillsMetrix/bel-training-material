package java11exam;
import java.io.IOException;
import java.net.*;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
public class HttpExamples2 {

	public static void main(String[] args) throws Exception {
		 var client= HttpClient.newHttpClient();
		 
		 var request= HttpRequest.newBuilder()
				 .uri(URI.create("https://jsonplaceholder.typicode.com/posts/1"))
		 			.GET().build();
		 
		  client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
				 .thenApply(HttpResponse :: body)
				 .thenAccept(System.out::println)
				 .join();
		 System.out.println("Called...!");

	}

}
