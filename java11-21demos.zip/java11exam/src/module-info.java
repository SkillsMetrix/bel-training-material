module java11exam {
	requires java.net.http;
}