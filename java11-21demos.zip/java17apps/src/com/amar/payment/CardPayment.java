package com.amar.payment;
public record CardPayment(String cardNumber, double amount) implements Payment {}
