package com.amar.payment;

public sealed interface Payment
        permits UpiPayment, CardPayment, WalletPayment {}
