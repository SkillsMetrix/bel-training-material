package com.amar.payment;
public class PaymentProcessor {

    public static String process(Payment payment) {    

        return switch (payment) {                    

            case UpiPayment(String upiId, double amt) ->
                    "Processing UPI Payment: " + upiId + " Amount=" + amt;

            case CardPayment(String card, double amt) ->
                    "Processing Card Payment: " + card + " Amount=" + amt;

            case WalletPayment w ->
                    "Processing Wallet Payment: " + w.walletId() + " Amount=" + w.amount();

   
        };
    }
}