package com.amar.payment;
public record UpiPayment(String upiId, double amount) implements Payment {}
