package com.amar.payment;
public final class WalletPayment implements Payment {

    private final String walletId;
    private final double amount;

    public WalletPayment(String walletId, double amount) {
        this.walletId = walletId;
        this.amount = amount;
    }

    public String walletId() { return walletId; }
    public double amount() { return amount; }
}
