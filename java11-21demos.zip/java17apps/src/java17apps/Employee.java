package java17apps;

public record Employee(int id, String name, double salary) {
	
	public double printSalary() {
		return salary+9089;
	}
	public Employee{
		if (salary <0 ) {
			throw new IllegalArgumentException("value cant be negative");
		}
	}
}
