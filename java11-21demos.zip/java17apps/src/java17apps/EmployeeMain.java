package java17apps;

import java.util.ArrayList;
import java.util.List;

public class EmployeeMain {

	public static void main(String[] args) {
		Employee employee= new Employee(101, "surya",10);
		
		 
		System.out.println(employee.name() + " "+ employee.id());
		System.out.println(employee.printSalary());
		
		List<Employee> al= new ArrayList<Employee>();
		al.add(new Employee(101,"sushma", 1230));
		al.add(new Employee(102,"amit", 2230));
		
		al.stream().filter(e -> e.salary() >2000).forEach(System.out::println);
	}

}
