package java17apps.sealed;

public final class Employee extends Person {

}
