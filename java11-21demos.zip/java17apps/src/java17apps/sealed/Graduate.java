package java17apps.sealed;

public final class Graduate extends Student {

}
