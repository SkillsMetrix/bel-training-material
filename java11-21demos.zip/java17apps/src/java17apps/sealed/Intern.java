package java17apps.sealed;

public non-sealed class Intern extends Person {

}
