package java17apps.sealed;

public sealed class Person permits Employee,Student,Intern{

}
