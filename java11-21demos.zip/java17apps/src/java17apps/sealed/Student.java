package java17apps.sealed;

public sealed class Student extends Person permits Graduate,UnderGraduate  {

}
