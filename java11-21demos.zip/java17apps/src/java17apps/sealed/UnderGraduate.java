package java17apps.sealed;

public final class UnderGraduate extends Student {

}
