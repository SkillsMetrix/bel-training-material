package com.lambda;


@FunctionalInterface
public interface WorkerInterface {
	
	public void doSomeWork();

}
