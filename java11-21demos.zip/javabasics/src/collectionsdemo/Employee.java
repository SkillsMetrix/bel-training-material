package collectionsdemo;

public class Employee {
	 
	
	private int empId;
	private String empName;
	private String empCity;

	 public Employee(int empId, String empName, String empCity) {
		 
		this.empId = empId;
		this.empName = empName;
		this.empCity = empCity;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empCity=" + empCity + "]";
	}
	
	
	
	
	

}
