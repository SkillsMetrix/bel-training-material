package com.sunlife.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.sunlife.exceptions.EmployeeNotFoundException;
import com.sunlife.model.Users;

@Service
public class AppService {
	List<Users> al = new ArrayList<Users>();

	public void addUser(Users users) {
		al.add(users);
	}

	public List<Users> loadUsers() {
		return al;
	}

	public Users searchUser(String user) {
		return al.stream().filter(emp -> emp.getUserName().equals(user)).findFirst()
				.orElseThrow(() -> new EmployeeNotFoundException("Employee Not Found " + user));
	}

	public void deleteUser(String user) {
		Users findUser = searchUser(user);
		al.remove(findUser);
	}

	public boolean updateUser(Users users) {
		for (Users us : al) {
			if (us.getUserName().equals(users.getUserName())) {
				// us.setUserName(users.getUserName());
				us.setEmail(users.getEmail());
				us.setPassword(users.getPassword());
				return true;
			}
		}
		return false;
	}

	public Users login(String uname, String pass) {
		return al.stream().filter(emp -> emp.getUserName().equals(uname) && emp.getPassword().equals(pass)).findFirst()
				.orElseThrow(() -> new RuntimeException("Invalid username or password"));
	}

}
