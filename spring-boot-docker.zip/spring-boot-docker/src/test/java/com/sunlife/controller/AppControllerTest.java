package com.sunlife.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MockMvcBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.sunlife.model.Users;
import com.sunlife.service.AppService;

import tools.jackson.databind.ObjectMapper;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import java.util.List;
@ExtendWith(MockitoExtension.class)
public class AppControllerTest {
	@Mock
	private AppService service;
	@InjectMocks
	private AppController controller;
	
	private MockMvc mockMvc;
	
	private ObjectMapper mapper;
	@BeforeEach
	void setUp() {
		mockMvc= MockMvcBuilders.standaloneSetup(controller).build();
		mapper= new ObjectMapper();
	}
	@Test
	void shouldAddUser() throws Exception{
		Users user1= new Users("alok", "alok@mail.com", "pass123", "lko");
		doNothing().when(service).addUser(any(Users.class));
		mockMvc.perform(post("/sunlife/addusers").contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(user1)
						
				)).andExpect(status().isOk());
		verify(service).addUser(any(Users.class));
	}
	@Test
	void shouldLoadUser()throws Exception {
		Users user1= new Users("alok", "alok@mail.com", "pass123", "lko");
		Users user2= new Users("sushant", "sushant@mail.com", "pass123", "mum");
		when(service.loadUsers())
		.thenReturn(List.of(user1,user2));
		mockMvc.perform(get("/sunlife/loadusers"))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$").isArray())
		.andExpect(jsonPath("$.length()").value(2))
		.andExpect(jsonPath("$[0].userName").value("alok"))
		.andExpect(jsonPath("$[1].userName").value("sushant"));
		verify(service).loadUsers();
	}
	
	
	@Test
	void shouldFindUser()throws Exception {
		Users user1= new Users("alok", "alok@mail.com", "pass123", "lko");
		Users user2= new Users("sushant", "sushant@mail.com", "pass123", "mum");
		 when(service.searchUser("alok"))
		 .thenReturn(user1);
		 mockMvc.perform(get("/sunlife/loaduser/alok"))
		 .andExpect(jsonPath("$.userName").value("alok"))
		 .andExpect(jsonPath("$.email").value("alok@mail.com"));
		 verify(service).searchUser("alok");
		 
	}

}
