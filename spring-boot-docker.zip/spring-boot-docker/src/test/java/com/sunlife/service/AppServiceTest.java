package com.sunlife.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.sunlife.model.Users;

public class AppServiceTest {
	
	private AppService service;
	
	@BeforeEach
	void setUp() {
		System.out.println("called before test case");
		service= new AppService();
	}
	@Test
	void shouldAddUser() {
		Users users= new Users("alok", "alok@mail.com", "pass123", "lko");
		service.addUser(users);
		
		List<Users> userList= service.loadUsers();
		
		assertEquals(1, userList.size());
		
	}
	@Test
	void shouldLoadUser() {
		Users user1= new Users("alok", "alok@mail.com", "pass123", "lko");
		Users user2= new Users("sushant", "sushant@mail.com", "pass123", "mum");
		service.addUser(user1);
		service.addUser(user2);
		
		List<Users> userList= service.loadUsers();
		assertEquals("alok", userList.get(0).getUserName());
		
		assertEquals(2, userList.size());
		
	}
	
	
	

}
