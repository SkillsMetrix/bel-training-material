package com.example.policy_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = "com.insurance")
@EntityScan("com.insurance.model")
@EnableJpaRepositories("com.insurance.repo")
@EnableDiscoveryClient
public class PolicyAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(PolicyAppApplication.class, args);
	}

}
