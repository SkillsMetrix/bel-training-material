package com.insurance.repo;

import java.util.List;


import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.insurance.model.Policy;
import com.insurance.model.PolicyStatus;
@Repository
public interface PolicyRepo extends CrudRepository<Policy, Integer> {
	@Modifying
	@Transactional
	@Query("""
			UPDATE Policy p
			SET p.policyHolderName= :name,
			p.policyType= :type,
			p.premiumAmount= :premium,
			p.policyStatus= :status
			where p.policyId= :id
			"""
			
			)
	int updatePolicy(@Param("id") int id,
			@Param("name") String name,
			@Param("type") String type,
			@Param("premium") double premium,
			@Param("status") PolicyStatus status);
	@Query("""
			SELECT p from Policy p WHERE p.policyStatus =:status
			""")
	List<Policy> findByStatus(@Param("status") PolicyStatus status);

}
