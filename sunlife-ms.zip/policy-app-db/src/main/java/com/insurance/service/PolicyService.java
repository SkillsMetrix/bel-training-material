package com.insurance.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.dao.PolicyDAO;
import com.insurance.exceptions.PolicyNotFoundException;
import com.insurance.model.Policy;
import com.insurance.model.PolicyStatus;
import com.insurance.repo.PolicyRepo;

@Service
public class PolicyService implements PolicyDAO {
	@Autowired
	private PolicyRepo repo;

	

	@Override
	public Policy createPolicy(Policy policy) {
		repo.save(policy);
		return policy;
	}

	@Override
	public List<Policy> loadPolicies() {
		
		return (List<Policy>) repo.findAll();
	}

	@Override
	public Policy getPolicyByID(int pid) {

		return repo.findById(pid).orElseThrow(() -> new PolicyNotFoundException("Policy Not found"));
	}

	@Override
	public void deletePolicy(int policyID) {
		Policy policy = getPolicyByID(policyID);
		repo.delete(policy);

	}

	@Override
	public Policy updatePolicy(int policyId, Policy policy) {
		int rowsUpdated =repo.updatePolicy(policyId, policy.getPolicyHolderName(), policy.getPolicyType(),
				policy.getPremiumAmount(), policy.getPolicyStatus());
		if(rowsUpdated ==0) {
			throw new PolicyNotFoundException("Policy Not Found "+ policyId);
		}
		return getPolicyByID(policyId);
	}

	@Override
	public List<Policy> loadPoliciesByStatus(PolicyStatus status) {

		return repo.findByStatus(status);
	}

}
