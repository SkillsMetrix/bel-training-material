package com.sunlife.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sunlife.model.Users;
import com.sunlife.service.AppService;

@RestController
@RequestMapping("/sunlife")
public class AppController {
	
	// dependency injection
	@Autowired
	private AppService service;
	
	
	@PostMapping("/addusers")
	public String addUsers(@RequestBody Users users) {
		service.addUser(users);
		 
		return "User Added sucessfully "+ users;
	}
	
	@PutMapping("/updateusers")
	public String updateUsers(@RequestBody Users users) {
		boolean updated= service.updateUser(users);
		if(updated) {
			return "User updated sucessfully";
		}
		 return "User not found";
		
	}
	
	@GetMapping("/loadusers")
	public List<Users> loadUsers() {
		return service.loadUsers();
	}
	@GetMapping("/loaduser/{name}")
	public ResponseEntity<Users> findUser(@PathVariable String name) {
			 return ResponseEntity.ok(service.searchUser(name));
	}
	
	@DeleteMapping("/deleteuser/{name}")
	public ResponseEntity<String> deleteUser(@PathVariable String name) {
		service.deleteUser(name);
		 return ResponseEntity.ok("Employee Deleted");
	}
	
}
