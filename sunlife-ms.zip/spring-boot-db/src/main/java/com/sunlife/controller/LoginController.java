package com.sunlife.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sunlife.model.Users;
import com.sunlife.service.AppService;

@RestController
@RequestMapping("/login")
public class LoginController {

	@Autowired
	private AppService service;

	@GetMapping("/userlogin")

	public ResponseEntity<Users> sayWelcome(@RequestBody Users users) {
		return ResponseEntity.ok(service.login(users.getUserName(), users.getPassword()));
	}

}
