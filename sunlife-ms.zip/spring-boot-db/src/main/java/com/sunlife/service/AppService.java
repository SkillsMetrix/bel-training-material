package com.sunlife.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.repo.UsersRepo;
import com.sunlife.exceptions.EmployeeNotFoundException;
import com.sunlife.model.Users;

@Service
public class AppService {
	List<Users> al = new ArrayList<Users>();
	
	@Autowired
	private UsersRepo repo;

	public void addUser(Users users) {
		repo.save(users);
	}

	public List<Users> loadUsers() {
		return (List<Users>) repo.findAll();
	}

	public Users searchUser(String user) {
		return al.stream().filter(emp -> emp.getUserName().equals(user)).findFirst()
				.orElseThrow(() -> new EmployeeNotFoundException("Employee Not Found " + user));
	}

	public void deleteUser(String user) {
		Users findUser = searchUser(user);
		al.remove(findUser);
	}

	public boolean updateUser(Users users) {
		for (Users us : al) {
			if (us.getUserName().equals(users.getUserName())) {
				// us.setUserName(users.getUserName());
				us.setEmail(users.getEmail());
				us.setPassword(users.getPassword());
				return true;
			}
		}
		return false;
	}

	public Users login(String uname, String pass) {
		return al.stream().filter(emp -> emp.getUserName().equals(uname) && emp.getPassword().equals(pass)).findFirst()
				.orElseThrow(() -> new RuntimeException("Invalid username or password"));
	}

}
